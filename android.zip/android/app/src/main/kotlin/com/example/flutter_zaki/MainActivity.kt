package com.example.flutter_zaki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
